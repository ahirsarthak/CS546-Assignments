const peopledata = require("./people");
const stocksdata = require("./stocks");

module.exports = {
  people: peopledata,
  stock: stocksdata,
};
