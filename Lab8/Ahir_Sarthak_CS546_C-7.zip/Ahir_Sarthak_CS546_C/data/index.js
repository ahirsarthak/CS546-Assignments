const searchData = require("./search");
const characData = require("./character");

module.exports = {
  search: searchData,
  character: characData,
};
